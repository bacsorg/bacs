#pragma once

#include <bunsan/error.hpp>

namespace bacs::statement_provider {

struct error : virtual bunsan::error {};

}  // namespace bacs::statement_provider
