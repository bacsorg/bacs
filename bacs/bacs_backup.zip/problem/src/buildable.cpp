#include <bacs/problem/buildable.hpp>

namespace bacs::problem {

buildable::~buildable() {}

}  // namespace bacs::problem
