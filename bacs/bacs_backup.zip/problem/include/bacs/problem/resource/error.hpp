#pragma once

#include <bacs/problem/error.hpp>

namespace bacs::problem::resource {

struct error : virtual problem::error {};

}  // namespace bacs::problem::resource
