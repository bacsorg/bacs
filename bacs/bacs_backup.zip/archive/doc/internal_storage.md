# Internal storage

## Repository storage

```
repository/
           ${problem_id}/
                         flags/${flag_i}
                         import_result
                         revision
                         ${problem.filename}
\endverbatim

\section pm_sec bunsan::pm

\verbatim
pm/
   bacs/
        problem/
                ${problem_id}/
                              {...unspecified...}
```
