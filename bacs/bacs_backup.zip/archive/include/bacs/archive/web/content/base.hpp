#pragma once

#include <cppcms/view.h>

#include <string>

namespace bacs::archive::web::content {

struct base : cppcms::base_content {};

}  // namespace bacs::archive::web::content
