#pragma once

#include <bacs/archive/web/content/base.hpp>

namespace bacs::archive::web::content {

struct base_form : base {};
struct base_response : base {};

}  // namespace bacs::archive::web::content
